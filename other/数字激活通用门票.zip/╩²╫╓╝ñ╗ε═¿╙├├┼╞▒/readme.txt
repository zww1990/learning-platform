输入通用密钥，然后将数字门票GenuineTicket.xml复制到目录C:\ProgramData\Microsoft\Windows\ClipSVC\GenuineTicket下。重启电脑后，联网的情况下，等一会就自动激活了。

如果嫌等的时间久，直接以管理员身份运行命令：Powershell Restart-Service ClipSVC，然后再执行一下激活命令slmgr -ato即可（重启电脑都省了~）
